create table if not exists public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  sku text unique,
  size text not null default '',
  color text not null default '',
  price_lak bigint check (price_lak is null or price_lak >= 0),
  stock integer not null default 0 check (stock >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint product_variant_combination_unique unique (product_id, size, color)
);

create index if not exists product_variants_product_id_idx
on public.product_variants(product_id);

alter table public.product_variants enable row level security;

drop policy if exists "Public can view active variants" on public.product_variants;
create policy "Public can view active variants" on public.product_variants
for select using (
  active = true and exists (
    select 1 from public.products p
    where p.id = product_variants.product_id and p.active = true
  )
);

drop policy if exists "Admins manage variants" on public.product_variants;
create policy "Admins manage variants" on public.product_variants
for all to authenticated using (public.is_admin())
with check (public.is_admin());

grant select on public.product_variants to anon, authenticated;
grant insert, update, delete on public.product_variants to authenticated;
