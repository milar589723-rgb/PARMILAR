import VirtualWardrobe from "@/components/VirtualWardrobe";

export default function WardrobePage() {
  return <VirtualWardrobe language="en" />;
}
