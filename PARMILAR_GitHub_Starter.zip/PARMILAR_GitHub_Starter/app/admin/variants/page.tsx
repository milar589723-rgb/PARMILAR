import VariantManager from "@/components/VariantManager";

type Props = {
  searchParams: { productId?: string };
};

export default function AdminVariantsPage({ searchParams }: Props) {
  const productId = searchParams.productId || "";
  return (
    <main style={{ minHeight: "100vh", padding: "32px 5%", background: "#101010", color: "#eee" }}>
      <h1 style={{ fontSize: 30, marginBottom: 24 }}>PARMILAR / ADMIN</h1>
      {!productId ? (
        <p>Add a product ID to the URL: /admin/variants?productId=YOUR_PRODUCT_UUID</p>
      ) : (
        <VariantManager productId={productId} />
      )}
    </main>
  );
}
